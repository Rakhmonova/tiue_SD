import tkinter as tk
from tkinter import PhotoImage


class SampleAPP(tk.Tk):
    def __init__(self, *arg, **kwargs):
        tk.Tk.__init__(self, *arg, **kwargs)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (StartPage, MenuPage, EndPage, ChooseBack):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            frame.grid(row=0, column=0, sticky="nsew")

            self.show_frame("StartPage")

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()


class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.controller.title('Security')
        self.controller.state('zoomed')
        self.controller.geometry('1250x650')
        self.controller.resizable(0, 0)


        self.backGroundImage = PhotoImage(file=r"images/security3.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)

        big_label = tk.Label(self, text=('Моделирование бизнес-процессов \n частного охранного предприятия'), font=('Bernard MT Condensed', 50, 'bold'), fg="#000"
                              , bg="#008585")
        big_label.pack(pady=20)
        def choose_Omg():
            controller.show_frame('MenuPage')
        cash_button = tk.Button(self, text="Услуги", command=choose_Omg,
                                font=('Bernard MT Condensed', 30, 'bold'), fg="#fff", bg="#000", width='20')
        cash_button.place(x=100, y=350)

        def choose_contact():
            controller.show_frame('EndPage')
        cash_button = tk.Button(self, text="Контакты", command=choose_contact,
                                font=('Bernard MT Condensed', 30, 'bold'), fg="#fff", bg="#000", width='20')
        cash_button.place(x=860, y=350)
        def choose_info():
            controller.show_frame('ChooseBack')
        cash_button = tk.Button(self, text="Заявка", command=choose_info,
                                font=('Bernard MT Condensed', 35, 'bold'), fg="yellow", bg="#000", width='20')
        cash_button.place(x=450, y=500)





class ChooseBack(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="black")
        self.controller = controller
        self.controller.title('Security')

        self.backGroundImage = PhotoImage(file=r"images/security2.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)
        def return_page():
            controller.show_frame('StartPage')

        return_button = tk.Button(self, text="назад", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="blue", bg="#fff")
        return_button.pack()
        in_login_label = tk.Label(self, text="полное имя", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="blue", bg="#fff")
        in_login_label.place(x=400, y=200)
        in_login = tk.StringVar()

        in_login_entry = tk.Entry(self, textvariable=in_login, font=('Bernard MT Condensed', 15, 'bold'), fg="green",
                                  bg="#fff")
        in_login_entry.place(x=400, y=230)
        in_project_label = tk.Label(self, text="организация", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="blue", bg="#fff")
        in_project_label.place(x=400, y=280)
        in_project = tk.StringVar()

        in_project_entry = tk.Entry(self, textvariable=in_project, font=('Bernard MT Condensed', 15, 'bold'), fg="green",
                                  bg="#fff")
        in_project_entry.place(x=400, y=310)

        in_address_label = tk.Label(self, text="адрес", font=('Bernard MT Condensed', 15, 'bold'),
                              fg="blue", bg="#fff")
        in_address_label.place(x=400, y=360)
        in_address = tk.StringVar()
        in_address_entry = tk.Entry(self, textvariable=in_address, font=('Bernard MT Condensed', 15, 'bold'), fg="green",
                              bg="#fff")
        in_address_entry.place(x=400, y=390)
        in_number_label = tk.Label(self, text="номер", font=('Bernard MT Condensed', 15, 'bold'),
                                    fg="blue", bg="#fff")
        in_number_label.place(x=400, y=440)
        in_number = tk.IntVar()
        in_number_entry = tk.Entry(self, textvariable=in_number, font=('Bernard MT Condensed', 15, 'bold'),
                                    fg="green",bg="#fff")
        in_number_entry.place(x=400, y=470)

        def choose_okey():
            if in_login.get() == "" or in_number.get() == "" or in_address.get()== "" or in_project.get()=="":
                cash_label['text'] = "Пожалуйста заполните!!"
            elif in_login.get() == "" and in_number.get() == "" or in_address.get()== "" or in_project.get()=="":
                cash_label['text'] = "Пожалуйста заполните!!"
            elif in_login.get() == "" and in_number.get() == "" and in_address.get() == "" or in_project.get() == "":
                cash_label['text'] = "Пожалуйста заполните!!"
            elif in_login.get() == "" and in_number.get() == "" and in_address.get() == "" and in_project.get() == "":
                cash_label['text'] = "Пожалуйста заполните!!"
            elif in_login.get() == "" or in_number.get() == "" and in_address.get() == "" and in_project.get() == "":
                cash_label['text'] = "Пожалуйста заполните!!"
            elif in_login.get() == "" or in_number.get() == "" or in_address.get() == "" and in_project.get() == "":
                cash_label['text'] = "Пожалуйста заполните!!"
            elif in_login.get() == "" or in_number.get() == "" and in_address.get() == "" or in_project.get() == "":
                cash_label['text'] = "Пожалуйста заполните!!"
            elif in_login.get() == ""and in_number.get() == "" or in_address.get() == "" and in_project.get() == "":
                cash_label['text'] = "Пожалуйста заполните!!"
            elif in_number.get() == 0:
                cash_label['text'] = "Пожалуйста заполните!!"

            else:
                cash_label['text'] = "успешно отправлен!!"


        cash_label = tk.Label(self, font=('Bernard MT Condensed', 40, 'bold'),
                              fg="red", bg="#000")
        cash_label.place(x=400, y=600)


        cash_button = tk.Button(self, text="enter", command=choose_okey,
                                font=('Bernard MT Condensed', 15, 'bold'), fg="blue", bg="#fff", width='25')
        cash_button.place(x=400, y=520)







class MenuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="black")
        self.controller = controller
        self.controller.title('Security')

        self.backGroundImage = PhotoImage(file=r"images/security6.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)
        big_lable = tk.Label(self, text="услуги", font=('Bernard MT Condensed', 50, 'bold'),
                             fg="#fff", bg="blue")
        big_lable.place(x=0 ,y=0)

        def return_page():
            controller.show_frame('StartPage')

        return_button = tk.Button(self, text="назад", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="blue", bg="#fff")
        return_button.pack()



        text1_label = tk.Label(self, text="1 Защита жизни и \n здоровья граждан", font=('Bernard MT Condensed', 40, 'bold'),
                              fg="blue", bg="#fff")
        text1_label.place(x=100, y=100)
        text2_label = tk.Label(self, text="2 Охрана имущества \n собственников .", font=('Bernard MT Condensed', 40, 'bold'),
                              fg="blue", bg="#fff")
        text2_label.place(x=700, y=300)
        text3_label = tk.Label(self, text="3 Обеспеченье порядкав местах \n проведения массовых мероприятий.", font=('Bernard MT Condensed', 40, 'bold'),
                              fg="blue", bg="#fff")
        text3_label.place(x=350, y=500)

class EndPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#FF7578")
        self.controller = controller
        self.controller.title('Security')

        self.backGroundImage = PhotoImage(file=r"images/security.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)
        big_lable = tk.Label(self, text="Contact", font=('Bernard MT Condensed', 50, 'bold'), fg="brown",
                             bg="#fff")
        big_lable.place(x=0 , y=0)

        def return_page():
            controller.show_frame('StartPage')

        return_button = tk.Button(self, text="назад", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="green", bg="#fff")
        return_button.pack()


        text1_label = tk.Label(self, text="Адрес:", font=('Bernard MT Condensed', 30, 'bold'),
                               fg="#000", bg="#fff")
        text1_label.pack(pady=50)
        text2_label = tk.Label(self, text="г.Тошкент , ул.Амир Темур ", font=('Bernard MT Condensed', 25, 'bold'),
                               fg="blue", bg="#fff")
        text2_label.pack()
        text3_label = tk.Label(self, text="Телефон:+998999099009", font=('Bernard MT Condensed', 25, 'bold'),
                               fg="blue", bg="#fff")
        text3_label.pack(pady=70)
        text4_label = tk.Label(self, text="Email:security@mail.uz", font=('Bernard MT Condensed', 25, 'bold'),
                               fg="blue", bg="#fff")
        text4_label.pack(pady=50)

if __name__== "__main__":
    app = SampleAPP()
    app.mainloop()